import './App.css'
import './components/ChatBotElement'

function App() {

  return (
    <>
      <pdf-chatbot></pdf-chatbot>
    </>
  )
}

export default App
