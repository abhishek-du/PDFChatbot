import React from 'react';
import ReactDOM from 'react-dom/client';
import ChatInterface from './ChatInterface';
import styles from '../index.css?inline'; 

class ChatBotElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    const style = document.createElement('style');
    style.textContent = styles;
    this.shadowRoot.appendChild(style);

    const root = document.createElement('div');
    this.shadowRoot.appendChild(root);

    const reactRoot = ReactDOM.createRoot(root);
    reactRoot.render(<ChatInterface />);
  }
}

customElements.define('pdf-chatbot', ChatBotElement);
